# WordPress MySQL database migration
#
# Generated: Wednesday 13. December 2017 00:27 UTC
# Hostname: localhost
# Database: `henshawhenry`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-11-14 18:39:52', '2017-11-14 18:39:52', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=662 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://henshaw-henry.com', 'yes'),
(2, 'home', 'http://henshaw-henry.com', 'yes'),
(3, 'blogname', 'Henshaw &amp; Henry, PC', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1point21interactive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '4', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:19:"akismet/akismet.php";i:2;s:38:"post-duplicator/m4c-postduplicator.php";i:3;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'henshaw-henry', 'yes'),
(41, 'stylesheet', 'henshaw-henry', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:3:{i:3;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}i:4;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '138', 'yes'),
(84, 'page_on_front', '6', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:3:{i:3;a:3:{s:5:"title";s:0:"";s:6:"number";i:5;s:9:"show_date";b:0;}i:4;a:3:{s:5:"title";s:0:"";s:6:"number";i:5;s:9:"show_date";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:3:{i:3;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}i:4;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:4:{s:19:"recent_posts_widget";a:3:{i:0;s:14:"recent-posts-3";i:1;s:12:"categories-3";i:2;s:10:"archives-3";}s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:3:{i:0;s:14:"recent-posts-4";i:1;s:12:"categories-4";i:2;s:10:"archives-4";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'cron', 'a:5:{i:1513147193;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1513190414;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1513190972;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1513209191;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(109, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1510685056;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(135, 'can_compress_scripts', '1', 'no'),
(136, 'current_theme', '', 'yes'),
(137, 'theme_mods_henshaw-henry', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:5:{s:9:"main_menu";i:2;s:10:"pa_sidebar";i:2;s:17:"pa_directory_menu";i:0;s:25:"pa_directory_menu_col_one";i:4;s:25:"pa_directory_menu_col_two";i:5;}}', 'yes'),
(138, 'theme_switched', '', 'yes'),
(141, 'recently_activated', 'a:0:{}', 'yes'),
(143, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(144, 'akismet_strictness', '0', 'yes'),
(145, 'akismet_show_user_comments_approved', '0', 'yes'),
(146, 'wordpress_api_key', 'eca67b738eea', 'yes'),
(147, 'akismet_spam_count', '0', 'yes'),
(153, 'WPLANG', '', 'yes'),
(292, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(293, 'rg_form_version', '2.2.5', 'yes'),
(296, 'rg_gforms_key', '2607c8f786b4fc8d43bc9ecae92fcaa1', 'yes'),
(297, 'rg_gforms_disable_css', '1', 'yes'),
(298, 'rg_gforms_enable_html5', '0', 'yes'),
(299, 'gform_enable_noconflict', '0', 'yes'),
(300, 'rg_gforms_enable_akismet', '0', 'yes'),
(301, 'rg_gforms_captcha_public_key', '', 'yes'),
(302, 'rg_gforms_captcha_private_key', '', 'yes'),
(303, 'rg_gforms_currency', 'USD', 'yes'),
(304, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(308, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(309, 'gf_is_upgrading', '0', 'yes'),
(310, 'gf_previous_db_version', '0', 'yes'),
(311, 'gf_db_version', '2.2.5', 'yes'),
(455, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(512, 'wpmdb_settings', 'a:7:{s:11:"max_request";i:1048576;s:3:"key";s:32:"xonQfSUsetuOPaMXj1HM62EkkgMVyI9V";s:10:"allow_pull";b:0;s:10:"allow_push";b:0;s:8:"profiles";a:0:{}s:7:"licence";s:0:"";s:10:"verify_ssl";b:0;}', 'yes'),
(628, 'mtphr_post_duplicator_settings', '', 'yes'),
(649, 'category_children', 'a:0:{}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=732 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 2, '_wp_trash_meta_status', 'publish'),
(3, 2, '_wp_trash_meta_time', '1510685306'),
(4, 2, '_wp_desired_post_slug', 'sample-page'),
(5, 1, '_wp_trash_meta_status', 'publish'),
(6, 1, '_wp_trash_meta_time', '1510685310'),
(7, 1, '_wp_desired_post_slug', 'hello-world'),
(8, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1510685241:1'),
(11, 6, '_wp_page_template', 'page-home.php'),
(12, 8, '_edit_last', '1'),
(13, 8, '_edit_lock', '1510870629:1'),
(14, 8, '_wp_page_template', 'default'),
(15, 11, '_edit_last', '1'),
(16, 11, '_edit_lock', '1512600276:1'),
(17, 11, '_wp_page_template', 'default'),
(18, 13, '_edit_last', '1'),
(19, 13, '_wp_page_template', 'default'),
(20, 13, '_edit_lock', '1512683006:1'),
(21, 15, '_edit_last', '1'),
(22, 15, '_edit_lock', '1512683018:1'),
(23, 15, '_wp_page_template', 'default'),
(24, 17, '_edit_last', '1'),
(25, 17, '_edit_lock', '1512683033:1'),
(26, 17, '_wp_page_template', 'default'),
(27, 19, '_edit_last', '1'),
(28, 19, '_edit_lock', '1512683051:1'),
(29, 19, '_wp_page_template', 'default'),
(30, 21, '_edit_last', '1'),
(31, 21, '_edit_lock', '1512683065:1'),
(32, 21, '_wp_page_template', 'default'),
(33, 23, '_edit_last', '1'),
(34, 23, '_edit_lock', '1512683077:1'),
(35, 23, '_wp_page_template', 'default'),
(36, 25, '_edit_last', '1'),
(37, 25, '_edit_lock', '1512683096:1'),
(38, 25, '_wp_page_template', 'default'),
(39, 27, '_edit_last', '1'),
(40, 27, '_edit_lock', '1512683112:1'),
(41, 27, '_wp_page_template', 'default'),
(42, 29, '_edit_last', '1'),
(43, 29, '_wp_page_template', 'default'),
(44, 29, '_edit_lock', '1512683134:1'),
(45, 31, '_edit_last', '1'),
(46, 31, '_edit_lock', '1512683150:1'),
(47, 31, '_wp_page_template', 'default'),
(48, 33, '_edit_last', '1'),
(49, 33, '_edit_lock', '1512683168:1'),
(50, 33, '_wp_page_template', 'default'),
(51, 35, '_menu_item_type', 'post_type'),
(52, 35, '_menu_item_menu_item_parent', '0'),
(53, 35, '_menu_item_object_id', '6'),
(54, 35, '_menu_item_object', 'page'),
(55, 35, '_menu_item_target', ''),
(56, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 35, '_menu_item_xfn', ''),
(58, 35, '_menu_item_url', ''),
(59, 35, '_menu_item_orphaned', '1512683313'),
(60, 36, '_menu_item_type', 'post_type'),
(61, 36, '_menu_item_menu_item_parent', '0'),
(62, 36, '_menu_item_object_id', '31'),
(63, 36, '_menu_item_object', 'page'),
(64, 36, '_menu_item_target', ''),
(65, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(66, 36, '_menu_item_xfn', ''),
(67, 36, '_menu_item_url', ''),
(68, 36, '_menu_item_orphaned', '1512683313'),
(69, 37, '_menu_item_type', 'post_type'),
(70, 37, '_menu_item_menu_item_parent', '0'),
(71, 37, '_menu_item_object_id', '33'),
(72, 37, '_menu_item_object', 'page'),
(73, 37, '_menu_item_target', ''),
(74, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(75, 37, '_menu_item_xfn', ''),
(76, 37, '_menu_item_url', ''),
(77, 37, '_menu_item_orphaned', '1512683313'),
(78, 38, '_menu_item_type', 'post_type'),
(79, 38, '_menu_item_menu_item_parent', '0'),
(80, 38, '_menu_item_object_id', '6'),
(81, 38, '_menu_item_object', 'page'),
(82, 38, '_menu_item_target', ''),
(83, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(84, 38, '_menu_item_xfn', ''),
(85, 38, '_menu_item_url', ''),
(86, 38, '_menu_item_orphaned', '1512683313'),
(87, 39, '_menu_item_type', 'post_type'),
(88, 39, '_menu_item_menu_item_parent', '0'),
(89, 39, '_menu_item_object_id', '13'),
(90, 39, '_menu_item_object', 'page'),
(91, 39, '_menu_item_target', ''),
(92, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(93, 39, '_menu_item_xfn', ''),
(94, 39, '_menu_item_url', ''),
(95, 39, '_menu_item_orphaned', '1512683313'),
(96, 40, '_menu_item_type', 'post_type'),
(97, 40, '_menu_item_menu_item_parent', '0'),
(98, 40, '_menu_item_object_id', '25'),
(99, 40, '_menu_item_object', 'page'),
(100, 40, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(101, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(102, 40, '_menu_item_xfn', ''),
(103, 40, '_menu_item_url', ''),
(104, 40, '_menu_item_orphaned', '1512683313'),
(105, 41, '_menu_item_type', 'post_type'),
(106, 41, '_menu_item_menu_item_parent', '0'),
(107, 41, '_menu_item_object_id', '29'),
(108, 41, '_menu_item_object', 'page'),
(109, 41, '_menu_item_target', ''),
(110, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(111, 41, '_menu_item_xfn', ''),
(112, 41, '_menu_item_url', ''),
(113, 41, '_menu_item_orphaned', '1512683313'),
(114, 42, '_menu_item_type', 'post_type'),
(115, 42, '_menu_item_menu_item_parent', '0'),
(116, 42, '_menu_item_object_id', '23'),
(117, 42, '_menu_item_object', 'page'),
(118, 42, '_menu_item_target', ''),
(119, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(120, 42, '_menu_item_xfn', ''),
(121, 42, '_menu_item_url', ''),
(122, 42, '_menu_item_orphaned', '1512683313'),
(123, 43, '_menu_item_type', 'post_type'),
(124, 43, '_menu_item_menu_item_parent', '0'),
(125, 43, '_menu_item_object_id', '15'),
(126, 43, '_menu_item_object', 'page'),
(127, 43, '_menu_item_target', ''),
(128, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(129, 43, '_menu_item_xfn', ''),
(130, 43, '_menu_item_url', ''),
(131, 43, '_menu_item_orphaned', '1512683313'),
(132, 44, '_menu_item_type', 'post_type'),
(133, 44, '_menu_item_menu_item_parent', '0'),
(134, 44, '_menu_item_object_id', '27'),
(135, 44, '_menu_item_object', 'page'),
(136, 44, '_menu_item_target', ''),
(137, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(138, 44, '_menu_item_xfn', ''),
(139, 44, '_menu_item_url', ''),
(140, 44, '_menu_item_orphaned', '1512683313'),
(141, 45, '_menu_item_type', 'post_type'),
(142, 45, '_menu_item_menu_item_parent', '0'),
(143, 45, '_menu_item_object_id', '19'),
(144, 45, '_menu_item_object', 'page'),
(145, 45, '_menu_item_target', ''),
(146, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(147, 45, '_menu_item_xfn', ''),
(148, 45, '_menu_item_url', ''),
(149, 45, '_menu_item_orphaned', '1512683313'),
(150, 46, '_menu_item_type', 'post_type'),
(151, 46, '_menu_item_menu_item_parent', '0'),
(152, 46, '_menu_item_object_id', '21'),
(153, 46, '_menu_item_object', 'page'),
(154, 46, '_menu_item_target', ''),
(155, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(156, 46, '_menu_item_xfn', ''),
(157, 46, '_menu_item_url', ''),
(158, 46, '_menu_item_orphaned', '1512683313'),
(159, 47, '_menu_item_type', 'post_type'),
(160, 47, '_menu_item_menu_item_parent', '0'),
(161, 47, '_menu_item_object_id', '17'),
(162, 47, '_menu_item_object', 'page'),
(163, 47, '_menu_item_target', ''),
(164, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(165, 47, '_menu_item_xfn', ''),
(166, 47, '_menu_item_url', ''),
(167, 47, '_menu_item_orphaned', '1512683313'),
(168, 48, '_menu_item_type', 'post_type'),
(169, 48, '_menu_item_menu_item_parent', '0'),
(170, 48, '_menu_item_object_id', '11'),
(171, 48, '_menu_item_object', 'page'),
(172, 48, '_menu_item_target', ''),
(173, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(174, 48, '_menu_item_xfn', ''),
(175, 48, '_menu_item_url', ''),
(176, 48, '_menu_item_orphaned', '1512683313'),
(177, 49, '_menu_item_type', 'post_type'),
(178, 49, '_menu_item_menu_item_parent', '0'),
(179, 49, '_menu_item_object_id', '8'),
(180, 49, '_menu_item_object', 'page'),
(181, 49, '_menu_item_target', ''),
(182, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(183, 49, '_menu_item_xfn', ''),
(184, 49, '_menu_item_url', ''),
(185, 49, '_menu_item_orphaned', '1512683314'),
(195, 51, '_menu_item_type', 'post_type'),
(196, 51, '_menu_item_menu_item_parent', '62'),
(197, 51, '_menu_item_object_id', '29'),
(198, 51, '_menu_item_object', 'page'),
(199, 51, '_menu_item_target', ''),
(200, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(201, 51, '_menu_item_xfn', ''),
(202, 51, '_menu_item_url', ''),
(204, 52, '_menu_item_type', 'post_type'),
(205, 52, '_menu_item_menu_item_parent', '62'),
(206, 52, '_menu_item_object_id', '27'),
(207, 52, '_menu_item_object', 'page'),
(208, 52, '_menu_item_target', ''),
(209, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(210, 52, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(211, 52, '_menu_item_url', ''),
(213, 53, '_menu_item_type', 'post_type'),
(214, 53, '_menu_item_menu_item_parent', '62'),
(215, 53, '_menu_item_object_id', '25'),
(216, 53, '_menu_item_object', 'page'),
(217, 53, '_menu_item_target', ''),
(218, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(219, 53, '_menu_item_xfn', ''),
(220, 53, '_menu_item_url', ''),
(222, 54, '_menu_item_type', 'post_type'),
(223, 54, '_menu_item_menu_item_parent', '62'),
(224, 54, '_menu_item_object_id', '23'),
(225, 54, '_menu_item_object', 'page'),
(226, 54, '_menu_item_target', ''),
(227, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(228, 54, '_menu_item_xfn', ''),
(229, 54, '_menu_item_url', ''),
(231, 55, '_menu_item_type', 'post_type'),
(232, 55, '_menu_item_menu_item_parent', '62'),
(233, 55, '_menu_item_object_id', '21'),
(234, 55, '_menu_item_object', 'page'),
(235, 55, '_menu_item_target', ''),
(236, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(237, 55, '_menu_item_xfn', ''),
(238, 55, '_menu_item_url', ''),
(240, 56, '_menu_item_type', 'post_type'),
(241, 56, '_menu_item_menu_item_parent', '62'),
(242, 56, '_menu_item_object_id', '19'),
(243, 56, '_menu_item_object', 'page'),
(244, 56, '_menu_item_target', ''),
(245, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(246, 56, '_menu_item_xfn', ''),
(247, 56, '_menu_item_url', ''),
(249, 57, '_menu_item_type', 'post_type'),
(250, 57, '_menu_item_menu_item_parent', '62'),
(251, 57, '_menu_item_object_id', '17'),
(252, 57, '_menu_item_object', 'page'),
(253, 57, '_menu_item_target', ''),
(254, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(255, 57, '_menu_item_xfn', ''),
(256, 57, '_menu_item_url', ''),
(258, 58, '_menu_item_type', 'post_type'),
(259, 58, '_menu_item_menu_item_parent', '62'),
(260, 58, '_menu_item_object_id', '15'),
(261, 58, '_menu_item_object', 'page'),
(262, 58, '_menu_item_target', ''),
(263, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(264, 58, '_menu_item_xfn', ''),
(265, 58, '_menu_item_url', ''),
(285, 61, '_menu_item_type', 'post_type'),
(286, 61, '_menu_item_menu_item_parent', '0'),
(287, 61, '_menu_item_object_id', '13'),
(288, 61, '_menu_item_object', 'page'),
(289, 61, '_menu_item_target', ''),
(290, 61, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(291, 61, '_menu_item_xfn', ''),
(292, 61, '_menu_item_url', ''),
(293, 61, '_menu_item_orphaned', '1512685357'),
(294, 62, '_menu_item_type', 'custom'),
(295, 62, '_menu_item_menu_item_parent', '0'),
(296, 62, '_menu_item_object_id', '62'),
(297, 62, '_menu_item_object', 'custom'),
(298, 62, '_menu_item_target', ''),
(299, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(300, 62, '_menu_item_xfn', ''),
(301, 62, '_menu_item_url', ''),
(303, 63, '_edit_last', '1'),
(304, 63, '_edit_lock', '1512751380:1'),
(305, 63, '_wp_page_template', 'page-contact.php'),
(306, 65, '_edit_last', '1'),
(307, 65, '_wp_page_template', 'page-videocenter.php'),
(308, 65, '_edit_lock', '1512758200:1'),
(309, 67, '_edit_last', '1'),
(310, 67, '_edit_lock', '1512775170:1'),
(311, 67, '_wp_page_template', 'page-practiceareas-directory.php'),
(312, 69, '_edit_last', '1'),
(313, 69, '_edit_lock', '1512775328:1'),
(314, 69, '_wp_page_template', 'default'),
(315, 71, '_edit_last', '1'),
(316, 71, '_edit_lock', '1512775385:1'),
(317, 69, '_wp_trash_meta_status', 'publish'),
(318, 69, '_wp_trash_meta_time', '1512775511'),
(319, 69, '_wp_desired_post_slug', 'estate-planning-2'),
(320, 71, '_wp_page_template', 'default'),
(321, 73, '_edit_last', '1'),
(322, 73, '_edit_lock', '1512775411:1'),
(323, 73, '_wp_page_template', 'default'),
(324, 75, '_edit_last', '1'),
(325, 75, '_edit_lock', '1512775436:1'),
(326, 75, '_wp_page_template', 'default'),
(327, 77, '_edit_last', '1'),
(328, 77, '_edit_lock', '1512775448:1'),
(329, 77, '_wp_page_template', 'default'),
(330, 79, '_edit_last', '1'),
(331, 79, '_edit_lock', '1512775472:1'),
(332, 79, '_wp_page_template', 'default'),
(333, 81, '_edit_last', '1'),
(334, 81, '_edit_lock', '1512775495:1'),
(335, 81, '_wp_page_template', 'default'),
(336, 83, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(337, 83, '_wp_page_template', 'default'),
(338, 83, '_edit_lock', '1512775518:1'),
(339, 85, '_edit_last', '1'),
(340, 85, '_edit_lock', '1512775542:1'),
(341, 85, '_wp_page_template', 'default'),
(342, 87, '_edit_last', '1'),
(343, 87, '_edit_lock', '1512775604:1'),
(344, 87, '_wp_page_template', 'default'),
(345, 89, '_menu_item_type', 'post_type'),
(346, 89, '_menu_item_menu_item_parent', '135'),
(347, 89, '_menu_item_object_id', '71'),
(348, 89, '_menu_item_object', 'page'),
(349, 89, '_menu_item_target', ''),
(350, 89, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(351, 89, '_menu_item_xfn', ''),
(352, 89, '_menu_item_url', ''),
(354, 90, '_menu_item_type', 'post_type'),
(355, 90, '_menu_item_menu_item_parent', '135'),
(356, 90, '_menu_item_object_id', '73'),
(357, 90, '_menu_item_object', 'page'),
(358, 90, '_menu_item_target', ''),
(359, 90, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(360, 90, '_menu_item_xfn', ''),
(361, 90, '_menu_item_url', ''),
(363, 91, '_menu_item_type', 'post_type'),
(364, 91, '_menu_item_menu_item_parent', '0'),
(365, 91, '_menu_item_object_id', '81'),
(366, 91, '_menu_item_object', 'page'),
(367, 91, '_menu_item_target', ''),
(368, 91, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(369, 91, '_menu_item_xfn', ''),
(370, 91, '_menu_item_url', ''),
(371, 91, '_menu_item_orphaned', '1512775873'),
(372, 92, '_menu_item_type', 'post_type'),
(373, 92, '_menu_item_menu_item_parent', '0'),
(374, 92, '_menu_item_object_id', '87'),
(375, 92, '_menu_item_object', 'page'),
(376, 92, '_menu_item_target', ''),
(377, 92, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(378, 92, '_menu_item_xfn', ''),
(379, 92, '_menu_item_url', ''),
(380, 92, '_menu_item_orphaned', '1512775873'),
(381, 93, '_menu_item_type', 'post_type'),
(382, 93, '_menu_item_menu_item_parent', '135'),
(383, 93, '_menu_item_object_id', '75'),
(384, 93, '_menu_item_object', 'page'),
(385, 93, '_menu_item_target', ''),
(386, 93, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(387, 93, '_menu_item_xfn', ''),
(388, 93, '_menu_item_url', ''),
(399, 95, '_menu_item_type', 'post_type'),
(400, 95, '_menu_item_menu_item_parent', '136'),
(401, 95, '_menu_item_object_id', '79'),
(402, 95, '_menu_item_object', 'page'),
(403, 95, '_menu_item_target', ''),
(404, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(405, 95, '_menu_item_xfn', ''),
(406, 95, '_menu_item_url', ''),
(408, 96, '_menu_item_type', 'post_type'),
(409, 96, '_menu_item_menu_item_parent', '0'),
(410, 96, '_menu_item_object_id', '83'),
(411, 96, '_menu_item_object', 'page'),
(412, 96, '_menu_item_target', ''),
(413, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(414, 96, '_menu_item_xfn', ''),
(415, 96, '_menu_item_url', ''),
(416, 96, '_menu_item_orphaned', '1512776281'),
(417, 97, '_menu_item_type', 'post_type'),
(418, 97, '_menu_item_menu_item_parent', '0'),
(419, 97, '_menu_item_object_id', '85'),
(420, 97, '_menu_item_object', 'page'),
(421, 97, '_menu_item_target', ''),
(422, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(423, 97, '_menu_item_xfn', ''),
(424, 97, '_menu_item_url', ''),
(425, 97, '_menu_item_orphaned', '1512776281'),
(426, 98, '_menu_item_type', 'post_type'),
(427, 98, '_menu_item_menu_item_parent', '0'),
(428, 98, '_menu_item_object_id', '77'),
(429, 98, '_menu_item_object', 'page'),
(430, 98, '_menu_item_target', ''),
(431, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(432, 98, '_menu_item_xfn', ''),
(433, 98, '_menu_item_url', ''),
(434, 98, '_menu_item_orphaned', '1512776286'),
(435, 99, '_menu_item_type', 'post_type'),
(436, 99, '_menu_item_menu_item_parent', '0'),
(437, 99, '_menu_item_object_id', '79'),
(438, 99, '_menu_item_object', 'page'),
(439, 99, '_menu_item_target', ''),
(440, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(441, 99, '_menu_item_xfn', ''),
(442, 99, '_menu_item_url', ''),
(443, 99, '_menu_item_orphaned', '1512776286'),
(444, 100, '_menu_item_type', 'post_type'),
(445, 100, '_menu_item_menu_item_parent', '0'),
(446, 100, '_menu_item_object_id', '33'),
(447, 100, '_menu_item_object', 'page'),
(448, 100, '_menu_item_target', ''),
(449, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(450, 100, '_menu_item_xfn', ''),
(451, 100, '_menu_item_url', ''),
(452, 100, '_menu_item_orphaned', '1512776296'),
(453, 101, '_menu_item_type', 'post_type'),
(454, 101, '_menu_item_menu_item_parent', '0'),
(455, 101, '_menu_item_object_id', '87'),
(456, 101, '_menu_item_object', 'page'),
(457, 101, '_menu_item_target', ''),
(458, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(459, 101, '_menu_item_xfn', ''),
(460, 101, '_menu_item_url', ''),
(461, 101, '_menu_item_orphaned', '1512776296'),
(462, 102, '_menu_item_type', 'post_type'),
(463, 102, '_menu_item_menu_item_parent', '0'),
(464, 102, '_menu_item_object_id', '81'),
(465, 102, '_menu_item_object', 'page'),
(466, 102, '_menu_item_target', ''),
(467, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(468, 102, '_menu_item_xfn', ''),
(469, 102, '_menu_item_url', ''),
(470, 102, '_menu_item_orphaned', '1512776296'),
(471, 103, '_menu_item_type', 'post_type'),
(472, 103, '_menu_item_menu_item_parent', '0'),
(473, 103, '_menu_item_object_id', '75'),
(474, 103, '_menu_item_object', 'page'),
(475, 103, '_menu_item_target', ''),
(476, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(477, 103, '_menu_item_xfn', ''),
(478, 103, '_menu_item_url', ''),
(479, 103, '_menu_item_orphaned', '1512776296'),
(480, 104, '_menu_item_type', 'post_type'),
(481, 104, '_menu_item_menu_item_parent', '0'),
(482, 104, '_menu_item_object_id', '73'),
(483, 104, '_menu_item_object', 'page'),
(484, 104, '_menu_item_target', ''),
(485, 104, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(486, 104, '_menu_item_xfn', ''),
(487, 104, '_menu_item_url', ''),
(488, 104, '_menu_item_orphaned', '1512776296'),
(489, 105, '_menu_item_type', 'post_type'),
(490, 105, '_menu_item_menu_item_parent', '0'),
(491, 105, '_menu_item_object_id', '71'),
(492, 105, '_menu_item_object', 'page'),
(493, 105, '_menu_item_target', ''),
(494, 105, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(495, 105, '_menu_item_xfn', ''),
(496, 105, '_menu_item_url', ''),
(497, 105, '_menu_item_orphaned', '1512776296'),
(498, 106, '_menu_item_type', 'post_type'),
(499, 106, '_menu_item_menu_item_parent', '0'),
(500, 106, '_menu_item_object_id', '13'),
(501, 106, '_menu_item_object', 'page'),
(502, 106, '_menu_item_target', ''),
(503, 106, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(504, 106, '_menu_item_xfn', ''),
(505, 106, '_menu_item_url', ''),
(507, 107, '_menu_item_type', 'post_type'),
(508, 107, '_menu_item_menu_item_parent', '106'),
(509, 107, '_menu_item_object_id', '25'),
(510, 107, '_menu_item_object', 'page'),
(511, 107, '_menu_item_target', ''),
(512, 107, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(513, 107, '_menu_item_xfn', ''),
(514, 107, '_menu_item_url', ''),
(516, 108, '_menu_item_type', 'post_type'),
(517, 108, '_menu_item_menu_item_parent', '106'),
(518, 108, '_menu_item_object_id', '29'),
(519, 108, '_menu_item_object', 'page'),
(520, 108, '_menu_item_target', ''),
(521, 108, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(522, 108, '_menu_item_xfn', ''),
(523, 108, '_menu_item_url', ''),
(525, 109, '_menu_item_type', 'post_type'),
(526, 109, '_menu_item_menu_item_parent', '106'),
(527, 109, '_menu_item_object_id', '23'),
(528, 109, '_menu_item_object', 'page'),
(529, 109, '_menu_item_target', ''),
(530, 109, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(531, 109, '_menu_item_xfn', ''),
(532, 109, '_menu_item_url', ''),
(534, 110, '_menu_item_type', 'post_type'),
(535, 110, '_menu_item_menu_item_parent', '106'),
(536, 110, '_menu_item_object_id', '15'),
(537, 110, '_menu_item_object', 'page'),
(538, 110, '_menu_item_target', ''),
(539, 110, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(540, 110, '_menu_item_xfn', ''),
(541, 110, '_menu_item_url', ''),
(543, 111, '_menu_item_type', 'post_type'),
(544, 111, '_menu_item_menu_item_parent', '106'),
(545, 111, '_menu_item_object_id', '27'),
(546, 111, '_menu_item_object', 'page'),
(547, 111, '_menu_item_target', ''),
(548, 111, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(549, 111, '_menu_item_xfn', ''),
(550, 111, '_menu_item_url', ''),
(552, 112, '_menu_item_type', 'post_type'),
(553, 112, '_menu_item_menu_item_parent', '106'),
(554, 112, '_menu_item_object_id', '19'),
(555, 112, '_menu_item_object', 'page') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(556, 112, '_menu_item_target', ''),
(557, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(558, 112, '_menu_item_xfn', ''),
(559, 112, '_menu_item_url', ''),
(561, 113, '_menu_item_type', 'post_type'),
(562, 113, '_menu_item_menu_item_parent', '106'),
(563, 113, '_menu_item_object_id', '21'),
(564, 113, '_menu_item_object', 'page'),
(565, 113, '_menu_item_target', ''),
(566, 113, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(567, 113, '_menu_item_xfn', ''),
(568, 113, '_menu_item_url', ''),
(570, 114, '_menu_item_type', 'post_type'),
(571, 114, '_menu_item_menu_item_parent', '106'),
(572, 114, '_menu_item_object_id', '17'),
(573, 114, '_menu_item_object', 'page'),
(574, 114, '_menu_item_target', ''),
(575, 114, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(576, 114, '_menu_item_xfn', ''),
(577, 114, '_menu_item_url', ''),
(579, 115, '_menu_item_type', 'post_type'),
(580, 115, '_menu_item_menu_item_parent', '0'),
(581, 115, '_menu_item_object_id', '77'),
(582, 115, '_menu_item_object', 'page'),
(583, 115, '_menu_item_target', ''),
(584, 115, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(585, 115, '_menu_item_xfn', ''),
(586, 115, '_menu_item_url', ''),
(588, 116, '_menu_item_type', 'post_type'),
(589, 116, '_menu_item_menu_item_parent', '115'),
(590, 116, '_menu_item_object_id', '79'),
(591, 116, '_menu_item_object', 'page'),
(592, 116, '_menu_item_target', ''),
(593, 116, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(594, 116, '_menu_item_xfn', ''),
(595, 116, '_menu_item_url', ''),
(597, 117, '_menu_item_type', 'post_type'),
(598, 117, '_menu_item_menu_item_parent', '0'),
(599, 117, '_menu_item_object_id', '33'),
(600, 117, '_menu_item_object', 'page'),
(601, 117, '_menu_item_target', ''),
(602, 117, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(603, 117, '_menu_item_xfn', ''),
(604, 117, '_menu_item_url', ''),
(606, 118, '_menu_item_type', 'post_type'),
(607, 118, '_menu_item_menu_item_parent', '117'),
(608, 118, '_menu_item_object_id', '71'),
(609, 118, '_menu_item_object', 'page'),
(610, 118, '_menu_item_target', ''),
(611, 118, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(612, 118, '_menu_item_xfn', ''),
(613, 118, '_menu_item_url', ''),
(615, 119, '_menu_item_type', 'post_type'),
(616, 119, '_menu_item_menu_item_parent', '117'),
(617, 119, '_menu_item_object_id', '73'),
(618, 119, '_menu_item_object', 'page'),
(619, 119, '_menu_item_target', ''),
(620, 119, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(621, 119, '_menu_item_xfn', ''),
(622, 119, '_menu_item_url', ''),
(624, 120, '_menu_item_type', 'post_type'),
(625, 120, '_menu_item_menu_item_parent', '117'),
(626, 120, '_menu_item_object_id', '81'),
(627, 120, '_menu_item_object', 'page'),
(628, 120, '_menu_item_target', ''),
(629, 120, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(630, 120, '_menu_item_xfn', ''),
(631, 120, '_menu_item_url', ''),
(633, 121, '_menu_item_type', 'post_type'),
(634, 121, '_menu_item_menu_item_parent', '117'),
(635, 121, '_menu_item_object_id', '87'),
(636, 121, '_menu_item_object', 'page'),
(637, 121, '_menu_item_target', ''),
(638, 121, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(639, 121, '_menu_item_xfn', ''),
(640, 121, '_menu_item_url', ''),
(642, 122, '_menu_item_type', 'post_type'),
(643, 122, '_menu_item_menu_item_parent', '117'),
(644, 122, '_menu_item_object_id', '75'),
(645, 122, '_menu_item_object', 'page'),
(646, 122, '_menu_item_target', ''),
(647, 122, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(648, 122, '_menu_item_xfn', ''),
(649, 122, '_menu_item_url', ''),
(651, 123, '_menu_item_type', 'post_type'),
(652, 123, '_menu_item_menu_item_parent', '0'),
(653, 123, '_menu_item_object_id', '83'),
(654, 123, '_menu_item_object', 'page'),
(655, 123, '_menu_item_target', ''),
(656, 123, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(657, 123, '_menu_item_xfn', ''),
(658, 123, '_menu_item_url', ''),
(660, 124, '_menu_item_type', 'post_type'),
(661, 124, '_menu_item_menu_item_parent', '123'),
(662, 124, '_menu_item_object_id', '85'),
(663, 124, '_menu_item_object', 'page'),
(664, 124, '_menu_item_target', ''),
(665, 124, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(666, 124, '_menu_item_xfn', ''),
(667, 124, '_menu_item_url', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(668, 125, '_edit_last', '1'),
(669, 125, '_edit_lock', '1512849147:1'),
(670, 125, '_wp_page_template', 'page-clienttestimonials.php'),
(671, 128, '_edit_last', '1'),
(672, 128, '_wp_page_template', 'page-attorney-directory.php'),
(673, 128, '_edit_lock', '1513017216:1'),
(674, 130, '_edit_last', '1'),
(675, 130, '_wp_page_template', 'page-aboutoutfirm.php'),
(676, 130, '_edit_lock', '1513029369:1'),
(677, 132, '_edit_last', '1'),
(678, 132, '_edit_lock', '1513036464:1'),
(679, 132, '_wp_page_template', 'page-att-bio.php'),
(680, 134, '_menu_item_type', 'custom'),
(681, 134, '_menu_item_menu_item_parent', '0'),
(682, 134, '_menu_item_object_id', '134'),
(683, 134, '_menu_item_object', 'custom'),
(684, 134, '_menu_item_target', ''),
(685, 134, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(686, 134, '_menu_item_xfn', ''),
(687, 134, '_menu_item_url', '#'),
(688, 134, '_menu_item_orphaned', '1513036673'),
(689, 135, '_menu_item_type', 'custom'),
(690, 135, '_menu_item_menu_item_parent', '0'),
(691, 135, '_menu_item_object_id', '135'),
(692, 135, '_menu_item_object', 'custom'),
(693, 135, '_menu_item_target', ''),
(694, 135, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(695, 135, '_menu_item_xfn', ''),
(696, 135, '_menu_item_url', '#'),
(698, 136, '_menu_item_type', 'custom'),
(699, 136, '_menu_item_menu_item_parent', '0'),
(700, 136, '_menu_item_object_id', '136'),
(701, 136, '_menu_item_object', 'custom'),
(702, 136, '_menu_item_target', ''),
(703, 136, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(704, 136, '_menu_item_xfn', ''),
(705, 136, '_menu_item_url', '#'),
(707, 138, '_edit_last', '1'),
(708, 138, '_edit_lock', '1513060559:1'),
(709, 138, '_wp_page_template', 'page-blog.php'),
(710, 140, '_edit_last', '1'),
(711, 140, '_edit_lock', '1513104616:1'),
(714, 142, '_edit_last', '1'),
(715, 142, '_edit_lock', '1513104616:1'),
(717, 143, '_edit_last', '1'),
(718, 143, '_edit_lock', '1513118946:1'),
(720, 144, '_edit_last', '1'),
(721, 144, '_edit_lock', '1513118940:1'),
(723, 145, '_edit_last', '1'),
(724, 145, '_edit_lock', '1513118933:1'),
(726, 146, '_edit_last', '1'),
(727, 146, '_edit_lock', '1513124695:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-11-14 18:39:52', '2017-11-14 18:39:52', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2017-11-14 18:48:30', '2017-11-14 18:48:30', '', 0, 'http://henshaw-henry.com/?p=1', 0, 'post', '', 1),
(2, 1, '2017-11-14 18:39:52', '2017-11-14 18:39:52', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://henshaw-henry.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2017-11-14 18:48:26', '2017-11-14 18:48:26', '', 0, 'http://henshaw-henry.com/?page_id=2', 0, 'page', '', 0),
(4, 1, '2017-11-14 18:48:26', '2017-11-14 18:48:26', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://henshaw-henry.com/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-11-14 18:48:26', '2017-11-14 18:48:26', '', 2, 'http://henshaw-henry.com/2017/11/14/2-revision-v1/', 0, 'revision', '', 0),
(5, 1, '2017-11-14 18:48:30', '2017-11-14 18:48:30', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2017-11-14 18:48:30', '2017-11-14 18:48:30', '', 1, 'http://henshaw-henry.com/2017/11/14/1-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2017-11-14 18:49:42', '2017-11-14 18:49:42', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-11-14 18:49:42', '2017-11-14 18:49:42', '', 0, 'http://henshaw-henry.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2017-11-14 18:49:42', '2017-11-14 18:49:42', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-11-14 18:49:42', '2017-11-14 18:49:42', '', 6, 'http://henshaw-henry.com/2017/11/14/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2017-11-16 22:19:19', '2017-11-16 22:19:19', '', 'Practice Area Page', '', 'publish', 'closed', 'closed', '', 'practice-area-page', '', '', '2017-11-16 22:19:19', '2017-11-16 22:19:19', '', 0, 'http://henshaw-henry.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2017-11-16 22:19:19', '2017-11-16 22:19:19', '', 'Practice Area Page', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-11-16 22:19:19', '2017-11-16 22:19:19', '', 8, 'http://henshaw-henry.com/2017/11/16/8-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2017-12-06 22:46:56', '2017-12-06 22:46:56', '', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2017-12-06 22:46:56', '2017-12-06 22:46:56', '', 0, 'http://henshaw-henry.com/?page_id=11', 0, 'page', '', 0),
(12, 1, '2017-12-06 22:46:56', '2017-12-06 22:46:56', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-12-06 22:46:56', '2017-12-06 22:46:56', '', 11, 'http://henshaw-henry.com/2017/12/06/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-12-07 21:45:43', '2017-12-07 21:45:43', '', 'Personal Injury', '', 'publish', 'closed', 'closed', '', 'personal-injury', '', '', '2017-12-07 21:45:43', '2017-12-07 21:45:43', '', 0, 'http://henshaw-henry.com/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-12-07 21:45:43', '2017-12-07 21:45:43', '', 'Personal Injury', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-12-07 21:45:43', '2017-12-07 21:45:43', '', 13, 'http://henshaw-henry.com/2017/12/07/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-12-07 21:45:59', '2017-12-07 21:45:59', '', 'Car Accidents', '', 'publish', 'closed', 'closed', '', 'car-accidents', '', '', '2017-12-07 21:45:59', '2017-12-07 21:45:59', '', 13, 'http://henshaw-henry.com/?page_id=15', 0, 'page', '', 0),
(16, 1, '2017-12-07 21:45:59', '2017-12-07 21:45:59', '', 'Car Accidents', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-12-07 21:45:59', '2017-12-07 21:45:59', '', 15, 'http://henshaw-henry.com/2017/12/07/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-12-07 21:46:15', '2017-12-07 21:46:15', '', 'Wrongful Death', '', 'publish', 'closed', 'closed', '', 'wrongful-death', '', '', '2017-12-07 21:46:15', '2017-12-07 21:46:15', '', 13, 'http://henshaw-henry.com/?page_id=17', 0, 'page', '', 0),
(18, 1, '2017-12-07 21:46:15', '2017-12-07 21:46:15', '', 'Wrongful Death', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-12-07 21:46:15', '2017-12-07 21:46:15', '', 17, 'http://henshaw-henry.com/2017/12/07/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-12-07 21:46:30', '2017-12-07 21:46:30', '', 'Drunk Driving Accidents', '', 'publish', 'closed', 'closed', '', 'drunk-driving-accidents', '', '', '2017-12-07 21:46:30', '2017-12-07 21:46:30', '', 13, 'http://henshaw-henry.com/?page_id=19', 0, 'page', '', 0),
(20, 1, '2017-12-07 21:46:30', '2017-12-07 21:46:30', '', 'Drunk Driving Accidents', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-12-07 21:46:30', '2017-12-07 21:46:30', '', 19, 'http://henshaw-henry.com/2017/12/07/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-12-07 21:46:46', '2017-12-07 21:46:46', '', 'Truck Accidents', '', 'publish', 'closed', 'closed', '', 'truck-accidents', '', '', '2017-12-07 21:46:46', '2017-12-07 21:46:46', '', 13, 'http://henshaw-henry.com/?page_id=21', 0, 'page', '', 0),
(22, 1, '2017-12-07 21:46:46', '2017-12-07 21:46:46', '', 'Truck Accidents', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-12-07 21:46:46', '2017-12-07 21:46:46', '', 21, 'http://henshaw-henry.com/2017/12/07/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-12-07 21:46:58', '2017-12-07 21:46:58', '', 'Bus Accidents', '', 'publish', 'closed', 'closed', '', 'bus-accidents', '', '', '2017-12-07 21:46:58', '2017-12-07 21:46:58', '', 13, 'http://henshaw-henry.com/?page_id=23', 0, 'page', '', 0),
(24, 1, '2017-12-07 21:46:58', '2017-12-07 21:46:58', '', 'Bus Accidents', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-12-07 21:46:58', '2017-12-07 21:46:58', '', 23, 'http://henshaw-henry.com/2017/12/07/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2017-12-07 21:47:12', '2017-12-07 21:47:12', '', 'Bike Accidents', '', 'publish', 'closed', 'closed', '', 'bike-accidents', '', '', '2017-12-07 21:47:12', '2017-12-07 21:47:12', '', 13, 'http://henshaw-henry.com/?page_id=25', 0, 'page', '', 0),
(26, 1, '2017-12-07 21:47:12', '2017-12-07 21:47:12', '', 'Bike Accidents', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-07 21:47:12', '2017-12-07 21:47:12', '', 25, 'http://henshaw-henry.com/2017/12/07/25-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2017-12-07 21:47:32', '2017-12-07 21:47:32', '', 'Dog Bites', '', 'publish', 'closed', 'closed', '', 'dog-bites', '', '', '2017-12-07 21:47:32', '2017-12-07 21:47:32', '', 13, 'http://henshaw-henry.com/?page_id=27', 0, 'page', '', 0),
(28, 1, '2017-12-07 21:47:32', '2017-12-07 21:47:32', '', 'Dog Bites', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2017-12-07 21:47:32', '2017-12-07 21:47:32', '', 27, 'http://henshaw-henry.com/2017/12/07/27-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2017-12-07 21:47:44', '2017-12-07 21:47:44', '', 'Brain Injuries', '', 'publish', 'closed', 'closed', '', 'brain-injuries', '', '', '2017-12-07 21:47:52', '2017-12-07 21:47:52', '', 13, 'http://henshaw-henry.com/?page_id=29', 0, 'page', '', 0),
(30, 1, '2017-12-07 21:47:44', '2017-12-07 21:47:44', '', 'Brain Injuries', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2017-12-07 21:47:44', '2017-12-07 21:47:44', '', 29, 'http://henshaw-henry.com/2017/12/07/29-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2017-12-07 21:48:12', '2017-12-07 21:48:12', '', 'Civil Litigation', '', 'publish', 'closed', 'closed', '', 'civil-litigation', '', '', '2017-12-07 21:48:12', '2017-12-07 21:48:12', '', 0, 'http://henshaw-henry.com/?page_id=31', 0, 'page', '', 0),
(32, 1, '2017-12-07 21:48:12', '2017-12-07 21:48:12', '', 'Civil Litigation', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2017-12-07 21:48:12', '2017-12-07 21:48:12', '', 31, 'http://henshaw-henry.com/2017/12/07/31-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2017-12-07 21:48:24', '2017-12-07 21:48:24', '', 'Estate Planning', '', 'publish', 'closed', 'closed', '', 'estate-planning', '', '', '2017-12-07 21:48:24', '2017-12-07 21:48:24', '', 0, 'http://henshaw-henry.com/?page_id=33', 0, 'page', '', 0),
(34, 1, '2017-12-07 21:48:24', '2017-12-07 21:48:24', '', 'Estate Planning', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2017-12-07 21:48:24', '2017-12-07 21:48:24', '', 33, 'http://henshaw-henry.com/2017/12/07/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=35', 1, 'nav_menu_item', '', 0),
(36, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=36', 1, 'nav_menu_item', '', 0),
(37, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=40', 1, 'nav_menu_item', '', 0),
(41, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=42', 1, 'nav_menu_item', '', 0),
(43, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=43', 1, 'nav_menu_item', '', 0),
(44, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=44', 1, 'nav_menu_item', '', 0),
(45, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=45', 1, 'nav_menu_item', '', 0),
(46, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=46', 1, 'nav_menu_item', '', 0),
(47, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 13, 'http://henshaw-henry.com/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=48', 1, 'nav_menu_item', '', 0),
(49, 1, '2017-12-07 21:48:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 21:48:33', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=49', 1, 'nav_menu_item', '', 0),
(51, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=51', 9, 'nav_menu_item', '', 0),
(52, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=52', 8, 'nav_menu_item', '', 0),
(53, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=53', 7, 'nav_menu_item', '', 0),
(54, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=54', 6, 'nav_menu_item', '', 0),
(55, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=55', 5, 'nav_menu_item', '', 0),
(56, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=56', 4, 'nav_menu_item', '', 0),
(57, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=57', 3, 'nav_menu_item', '', 0),
(58, 1, '2017-12-07 21:50:47', '2017-12-07 21:50:47', ' ', '', '', 'publish', 'closed', 'closed', '', '58', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 13, 'http://henshaw-henry.com/?p=58', 2, 'nav_menu_item', '', 0),
(61, 1, '2017-12-07 22:22:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-07 22:22:37', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=61', 1, 'nav_menu_item', '', 0),
(62, 1, '2017-12-07 22:24:25', '2017-12-07 22:24:25', '', 'Personal Injury', '', 'publish', 'closed', 'closed', '', 'personal-injury', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 0, 'http://henshaw-henry.com/?p=62', 1, 'nav_menu_item', '', 0),
(63, 1, '2017-12-08 16:44:11', '2017-12-08 16:44:11', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2017-12-08 16:45:20', '2017-12-08 16:45:20', '', 0, 'http://henshaw-henry.com/?page_id=63', 0, 'page', '', 0),
(64, 1, '2017-12-08 16:44:11', '2017-12-08 16:44:11', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2017-12-08 16:44:11', '2017-12-08 16:44:11', '', 63, 'http://henshaw-henry.com/2017/12/08/63-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2017-12-08 18:37:48', '2017-12-08 18:37:48', '', 'Video Center', '', 'publish', 'closed', 'closed', '', 'video-center', '', '', '2017-12-08 18:39:02', '2017-12-08 18:39:02', '', 0, 'http://henshaw-henry.com/?page_id=65', 0, 'page', '', 0),
(66, 1, '2017-12-08 18:37:48', '2017-12-08 18:37:48', '', 'Video Center', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-08 18:37:48', '2017-12-08 18:37:48', '', 65, 'http://henshaw-henry.com/2017/12/08/65-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2017-12-08 23:21:47', '2017-12-08 23:21:47', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2017-12-08 23:21:47', '2017-12-08 23:21:47', '', 0, 'http://henshaw-henry.com/?page_id=67', 0, 'page', '', 0),
(68, 1, '2017-12-08 23:21:47', '2017-12-08 23:21:47', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2017-12-08 23:21:47', '2017-12-08 23:21:47', '', 67, 'http://henshaw-henry.com/2017/12/08/67-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2017-12-08 23:24:29', '2017-12-08 23:24:29', '', 'Estate Planning', '', 'trash', 'closed', 'closed', '', 'estate-planning-2__trashed', '', '', '2017-12-08 23:25:11', '2017-12-08 23:25:11', '', 0, 'http://henshaw-henry.com/?page_id=69', 0, 'page', '', 0),
(70, 1, '2017-12-08 23:24:29', '2017-12-08 23:24:29', '', 'Estate Planning', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2017-12-08 23:24:29', '2017-12-08 23:24:29', '', 69, 'http://henshaw-henry.com/2017/12/08/69-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2017-12-08 23:25:23', '2017-12-08 23:25:23', '', 'Advanced Health Care Directives', '', 'publish', 'closed', 'closed', '', 'advanced-health-care-directives', '', '', '2017-12-08 23:25:23', '2017-12-08 23:25:23', '', 33, 'http://henshaw-henry.com/?page_id=71', 0, 'page', '', 0),
(72, 1, '2017-12-08 23:25:23', '2017-12-08 23:25:23', '', 'Advanced Health Care Directives', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2017-12-08 23:25:23', '2017-12-08 23:25:23', '', 71, 'http://henshaw-henry.com/2017/12/08/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2017-12-08 23:25:49', '2017-12-08 23:25:49', '', 'Components Of An Estate Plan', '', 'publish', 'closed', 'closed', '', 'components-of-an-estate-plan', '', '', '2017-12-08 23:25:49', '2017-12-08 23:25:49', '', 33, 'http://henshaw-henry.com/?page_id=73', 0, 'page', '', 0),
(74, 1, '2017-12-08 23:25:49', '2017-12-08 23:25:49', '', 'Components Of An Estate Plan', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2017-12-08 23:25:49', '2017-12-08 23:25:49', '', 73, 'http://henshaw-henry.com/2017/12/08/73-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-12-08 23:26:13', '2017-12-08 23:26:13', '', 'Estate Planning FAQ', '', 'publish', 'closed', 'closed', '', 'estate-planning-faq', '', '', '2017-12-08 23:26:13', '2017-12-08 23:26:13', '', 33, 'http://henshaw-henry.com/?page_id=75', 0, 'page', '', 0),
(76, 1, '2017-12-08 23:26:13', '2017-12-08 23:26:13', '', 'Estate Planning FAQ', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2017-12-08 23:26:13', '2017-12-08 23:26:13', '', 75, 'http://henshaw-henry.com/2017/12/08/75-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2017-12-08 23:26:30', '2017-12-08 23:26:30', '', 'Probate', '', 'publish', 'closed', 'closed', '', 'probate', '', '', '2017-12-08 23:26:30', '2017-12-08 23:26:30', '', 0, 'http://henshaw-henry.com/?page_id=77', 0, 'page', '', 0),
(78, 1, '2017-12-08 23:26:30', '2017-12-08 23:26:30', '', 'Probate', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-12-08 23:26:30', '2017-12-08 23:26:30', '', 77, 'http://henshaw-henry.com/2017/12/08/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2017-12-08 23:26:54', '2017-12-08 23:26:54', '', 'Benefits of Probate', '', 'publish', 'closed', 'closed', '', 'benefits-of-probate', '', '', '2017-12-08 23:26:54', '2017-12-08 23:26:54', '', 77, 'http://henshaw-henry.com/?page_id=79', 0, 'page', '', 0),
(80, 1, '2017-12-08 23:26:54', '2017-12-08 23:26:54', '', 'Benefits of Probate', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2017-12-08 23:26:54', '2017-12-08 23:26:54', '', 79, 'http://henshaw-henry.com/2017/12/08/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2017-12-08 23:27:16', '2017-12-08 23:27:16', '', 'Estate Administration', '', 'publish', 'closed', 'closed', '', 'estate-administration', '', '', '2017-12-08 23:27:16', '2017-12-08 23:27:16', '', 33, 'http://henshaw-henry.com/?page_id=81', 0, 'page', '', 0),
(82, 1, '2017-12-08 23:27:16', '2017-12-08 23:27:16', '', 'Estate Administration', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2017-12-08 23:27:16', '2017-12-08 23:27:16', '', 81, 'http://henshaw-henry.com/2017/12/08/81-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2017-12-08 23:27:39', '2017-12-08 23:27:39', '', 'Trust Administration', '', 'publish', 'closed', 'closed', '', 'trust-administration', '', '', '2017-12-08 23:27:39', '2017-12-08 23:27:39', '', 0, 'http://henshaw-henry.com/?page_id=83', 0, 'page', '', 0),
(84, 1, '2017-12-08 23:27:39', '2017-12-08 23:27:39', '', 'Trust Administration', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2017-12-08 23:27:39', '2017-12-08 23:27:39', '', 83, 'http://henshaw-henry.com/2017/12/08/83-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2017-12-08 23:28:01', '2017-12-08 23:28:01', '', 'Change of Beneficiary', '', 'publish', 'closed', 'closed', '', 'change-of-beneficiary', '', '', '2017-12-08 23:28:01', '2017-12-08 23:28:01', '', 83, 'http://henshaw-henry.com/?page_id=85', 0, 'page', '', 0),
(86, 1, '2017-12-08 23:28:01', '2017-12-08 23:28:01', '', 'Change of Beneficiary', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2017-12-08 23:28:01', '2017-12-08 23:28:01', '', 85, 'http://henshaw-henry.com/2017/12/08/85-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2017-12-08 23:28:22', '2017-12-08 23:28:22', '', 'Estate Administration', '', 'publish', 'closed', 'closed', '', 'estate-administration-2', '', '', '2017-12-08 23:28:22', '2017-12-08 23:28:22', '', 33, 'http://henshaw-henry.com/?page_id=87', 0, 'page', '', 0),
(88, 1, '2017-12-08 23:28:22', '2017-12-08 23:28:22', '', 'Estate Administration', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-12-08 23:28:22', '2017-12-08 23:28:22', '', 87, 'http://henshaw-henry.com/2017/12/08/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2017-12-08 23:33:33', '2017-12-08 23:33:33', ' ', '', '', 'publish', 'closed', 'closed', '', '89', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 33, 'http://henshaw-henry.com/?p=89', 11, 'nav_menu_item', '', 0),
(90, 1, '2017-12-08 23:33:33', '2017-12-08 23:33:33', ' ', '', '', 'publish', 'closed', 'closed', '', '90', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 33, 'http://henshaw-henry.com/?p=90', 12, 'nav_menu_item', '', 0),
(91, 1, '2017-12-08 23:31:13', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:31:13', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=91', 1, 'nav_menu_item', '', 0),
(92, 1, '2017-12-08 23:31:13', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:31:13', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=92', 1, 'nav_menu_item', '', 0),
(93, 1, '2017-12-08 23:33:33', '2017-12-08 23:33:33', ' ', '', '', 'publish', 'closed', 'closed', '', '93', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 33, 'http://henshaw-henry.com/?p=93', 13, 'nav_menu_item', '', 0),
(95, 1, '2017-12-08 23:33:33', '2017-12-08 23:33:33', ' ', '', '', 'publish', 'closed', 'closed', '', '95', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 77, 'http://henshaw-henry.com/?p=95', 15, 'nav_menu_item', '', 0),
(96, 1, '2017-12-08 23:38:01', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:01', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=96', 1, 'nav_menu_item', '', 0),
(97, 1, '2017-12-08 23:38:01', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:01', '0000-00-00 00:00:00', '', 83, 'http://henshaw-henry.com/?p=97', 1, 'nav_menu_item', '', 0),
(98, 1, '2017-12-08 23:38:06', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:06', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=98', 1, 'nav_menu_item', '', 0),
(99, 1, '2017-12-08 23:38:06', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:06', '0000-00-00 00:00:00', '', 77, 'http://henshaw-henry.com/?p=99', 1, 'nav_menu_item', '', 0),
(100, 1, '2017-12-08 23:38:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:16', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=100', 1, 'nav_menu_item', '', 0),
(101, 1, '2017-12-08 23:38:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:16', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=101', 1, 'nav_menu_item', '', 0),
(102, 1, '2017-12-08 23:38:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:16', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=102', 1, 'nav_menu_item', '', 0),
(103, 1, '2017-12-08 23:38:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:16', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=103', 1, 'nav_menu_item', '', 0),
(104, 1, '2017-12-08 23:38:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:16', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=104', 1, 'nav_menu_item', '', 0),
(105, 1, '2017-12-08 23:38:16', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-08 23:38:16', '0000-00-00 00:00:00', '', 33, 'http://henshaw-henry.com/?p=105', 1, 'nav_menu_item', '', 0),
(106, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '106', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 0, 'http://henshaw-henry.com/?p=106', 1, 'nav_menu_item', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(107, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '107', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=107', 2, 'nav_menu_item', '', 0),
(108, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=108', 3, 'nav_menu_item', '', 0),
(109, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=109', 4, 'nav_menu_item', '', 0),
(110, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '110', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=110', 5, 'nav_menu_item', '', 0),
(111, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '111', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=111', 6, 'nav_menu_item', '', 0),
(112, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=112', 7, 'nav_menu_item', '', 0),
(113, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '113', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=113', 8, 'nav_menu_item', '', 0),
(114, 1, '2017-12-08 23:42:39', '2017-12-08 23:42:39', ' ', '', '', 'publish', 'closed', 'closed', '', '114', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 13, 'http://henshaw-henry.com/?p=114', 9, 'nav_menu_item', '', 0),
(115, 1, '2017-12-08 23:42:57', '2017-12-08 23:42:57', ' ', '', '', 'publish', 'closed', 'closed', '', '115', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 0, 'http://henshaw-henry.com/?p=115', 10, 'nav_menu_item', '', 0),
(116, 1, '2017-12-08 23:42:57', '2017-12-08 23:42:57', ' ', '', '', 'publish', 'closed', 'closed', '', '116', '', '', '2017-12-08 23:42:57', '2017-12-08 23:42:57', '', 77, 'http://henshaw-henry.com/?p=116', 11, 'nav_menu_item', '', 0),
(117, 1, '2017-12-08 23:43:40', '2017-12-08 23:43:40', ' ', '', '', 'publish', 'closed', 'closed', '', '117', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 0, 'http://henshaw-henry.com/?p=117', 1, 'nav_menu_item', '', 0),
(118, 1, '2017-12-08 23:43:40', '2017-12-08 23:43:40', ' ', '', '', 'publish', 'closed', 'closed', '', '118', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 33, 'http://henshaw-henry.com/?p=118', 2, 'nav_menu_item', '', 0),
(119, 1, '2017-12-08 23:43:40', '2017-12-08 23:43:40', ' ', '', '', 'publish', 'closed', 'closed', '', '119', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 33, 'http://henshaw-henry.com/?p=119', 3, 'nav_menu_item', '', 0),
(120, 1, '2017-12-08 23:43:40', '2017-12-08 23:43:40', ' ', '', '', 'publish', 'closed', 'closed', '', '120', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 33, 'http://henshaw-henry.com/?p=120', 4, 'nav_menu_item', '', 0),
(121, 1, '2017-12-08 23:43:40', '2017-12-08 23:43:40', ' ', '', '', 'publish', 'closed', 'closed', '', '121', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 33, 'http://henshaw-henry.com/?p=121', 5, 'nav_menu_item', '', 0),
(122, 1, '2017-12-08 23:43:40', '2017-12-08 23:43:40', ' ', '', '', 'publish', 'closed', 'closed', '', '122', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 33, 'http://henshaw-henry.com/?p=122', 6, 'nav_menu_item', '', 0),
(123, 1, '2017-12-08 23:43:58', '2017-12-08 23:43:58', ' ', '', '', 'publish', 'closed', 'closed', '', '123', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 0, 'http://henshaw-henry.com/?p=123', 7, 'nav_menu_item', '', 0),
(124, 1, '2017-12-08 23:43:58', '2017-12-08 23:43:58', ' ', '', '', 'publish', 'closed', 'closed', '', '124', '', '', '2017-12-08 23:43:58', '2017-12-08 23:43:58', '', 83, 'http://henshaw-henry.com/?p=124', 8, 'nav_menu_item', '', 0),
(125, 1, '2017-12-09 19:54:49', '2017-12-09 19:54:49', '', 'Client Testimonials', '', 'publish', 'closed', 'closed', '', 'client-testimonials', '', '', '2017-12-09 19:54:49', '2017-12-09 19:54:49', '', 0, 'http://henshaw-henry.com/?page_id=125', 0, 'page', '', 0),
(126, 1, '2017-12-09 19:54:49', '2017-12-09 19:54:49', '', 'Client Testimonials', '', 'inherit', 'closed', 'closed', '', '125-revision-v1', '', '', '2017-12-09 19:54:49', '2017-12-09 19:54:49', '', 125, 'http://henshaw-henry.com/2017/12/09/125-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2017-12-11 17:07:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-12-11 17:07:34', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=127', 0, 'post', '', 0),
(128, 1, '2017-12-11 18:25:35', '2017-12-11 18:25:35', '', 'Attorney Overview', '', 'publish', 'closed', 'closed', '', 'attorney-overview', '', '', '2017-12-11 18:35:58', '2017-12-11 18:35:58', '', 0, 'http://henshaw-henry.com/?page_id=128', 0, 'page', '', 0),
(129, 1, '2017-12-11 18:25:35', '2017-12-11 18:25:35', '', 'Attorney Overview', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2017-12-11 18:25:35', '2017-12-11 18:25:35', '', 128, 'http://henshaw-henry.com/2017/12/11/128-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2017-12-11 21:55:47', '2017-12-11 21:55:47', '', 'About Our Firm', '', 'publish', 'closed', 'closed', '', 'about-our-firm', '', '', '2017-12-11 21:58:27', '2017-12-11 21:58:27', '', 0, 'http://henshaw-henry.com/?page_id=130', 0, 'page', '', 0),
(131, 1, '2017-12-11 21:55:47', '2017-12-11 21:55:47', '', 'About Our Firm', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2017-12-11 21:55:47', '2017-12-11 21:55:47', '', 130, 'http://henshaw-henry.com/2017/12/11/130-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2017-12-11 23:56:41', '2017-12-11 23:56:41', '', 'David S. Henshaw', '', 'publish', 'closed', 'closed', '', 'david-s-henshaw', '', '', '2017-12-11 23:56:41', '2017-12-11 23:56:41', '', 0, 'http://henshaw-henry.com/?page_id=132', 0, 'page', '', 0),
(133, 1, '2017-12-11 23:56:41', '2017-12-11 23:56:41', '', 'David S. Henshaw', '', 'inherit', 'closed', 'closed', '', '132-revision-v1', '', '', '2017-12-11 23:56:41', '2017-12-11 23:56:41', '', 132, 'http://henshaw-henry.com/2017/12/11/132-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2017-12-11 23:57:53', '0000-00-00 00:00:00', '', 'Estate Planning', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-11 23:57:53', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=134', 1, 'nav_menu_item', '', 0),
(135, 1, '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 'Estate Planning', '', 'publish', 'closed', 'closed', '', 'estate-planning', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 0, 'http://henshaw-henry.com/?p=135', 10, 'nav_menu_item', '', 0),
(136, 1, '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 'Probate', '', 'publish', 'closed', 'closed', '', 'probate', '', '', '2017-12-11 23:59:53', '2017-12-11 23:59:53', '', 0, 'http://henshaw-henry.com/?p=136', 14, 'nav_menu_item', '', 0),
(137, 1, '2017-12-12 06:35:47', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-12-12 06:35:47', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?page_id=137', 0, 'page', '', 0),
(138, 1, '2017-12-12 06:35:59', '2017-12-12 06:35:59', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-12-12 06:35:59', '2017-12-12 06:35:59', '', 0, 'http://henshaw-henry.com/?page_id=138', 0, 'page', '', 0),
(139, 1, '2017-12-12 06:35:59', '2017-12-12 06:35:59', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2017-12-12 06:35:59', '2017-12-12 06:35:59', '', 138, 'http://henshaw-henry.com/2017/12/12/138-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2017-12-12 18:51:33', '2017-12-12 18:51:33', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.', '', 'publish', 'open', 'open', '', 'duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed', '', '', '2017-12-12 18:51:33', '2017-12-12 18:51:33', '', 0, 'http://henshaw-henry.com/?p=140', 0, 'post', '', 0),
(141, 1, '2017-12-12 18:51:33', '2017-12-12 18:51:33', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2017-12-12 18:51:33', '2017-12-12 18:51:33', '', 140, 'http://henshaw-henry.com/2017/12/12/140-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2017-12-12 18:53:51', '2017-12-12 18:53:51', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy', '', 'publish', 'open', 'open', '', 'duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy', '', '', '2017-12-12 18:53:51', '2017-12-12 18:53:51', '', 0, 'http://henshaw-henry.com/2017/12/12/duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy/', 0, 'post', '', 0),
(143, 1, '2017-12-12 18:53:54', '2017-12-12 18:53:54', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy', '', 'publish', 'open', 'open', '', 'duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy', '', '', '2017-12-12 22:49:06', '2017-12-12 22:49:06', '', 0, 'http://henshaw-henry.com/2017/12/12/duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy/', 0, 'post', '', 0),
(144, 1, '2017-12-12 18:53:57', '2017-12-12 18:53:57', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy-copy', '', '', '2017-12-12 22:49:00', '2017-12-12 22:49:00', '', 0, 'http://henshaw-henry.com/2017/12/12/duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy-copy/', 0, 'post', '', 0),
(145, 1, '2017-12-12 19:34:56', '2017-12-12 19:34:56', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy-copy-copy', '', '', '2017-12-12 22:48:53', '2017-12-12 22:48:53', '', 0, 'http://henshaw-henry.com/2017/12/12/duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy-copy-copy/', 0, 'post', '', 0),
(146, 1, '2017-12-12 19:34:59', '2017-12-12 19:34:59', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.\r\n\r\nDonec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.\r\n\r\nDonec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.\r\n\r\nDonec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy  Copy  Copy  Copy', '', 'publish', 'open', 'open', '', 'duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy-copy-copy-copy', '', '', '2017-12-13 00:18:18', '2017-12-13 00:18:18', '', 0, 'http://henshaw-henry.com/2017/12/12/duis-in-nulla-a-nisl-gravida-sodales-a-et-ligula-pellentesque-dignissim-tortor-sed-facilisis-porttitor-tellus-tellus-tempus-ipsum-vitae-molestie-ante-nisi-sed-copy-copy-copy-copy-copy/', 0, 'post', '', 0),
(147, 1, '2017-12-12 22:48:53', '2017-12-12 22:48:53', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2017-12-12 22:48:53', '2017-12-12 22:48:53', '', 145, 'http://henshaw-henry.com/2017/12/12/145-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2017-12-12 22:49:00', '2017-12-12 22:49:00', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '144-revision-v1', '', '', '2017-12-12 22:49:00', '2017-12-12 22:49:00', '', 144, 'http://henshaw-henry.com/2017/12/12/144-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2017-12-12 22:49:06', '2017-12-12 22:49:06', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '143-revision-v1', '', '', '2017-12-12 22:49:06', '2017-12-12 22:49:06', '', 143, 'http://henshaw-henry.com/2017/12/12/143-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2017-12-13 00:17:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-12-13 00:17:56', '0000-00-00 00:00:00', '', 0, 'http://henshaw-henry.com/?p=150', 0, 'post', '', 0),
(151, 1, '2017-12-13 00:18:18', '2017-12-13 00:18:18', 'Donec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.\r\n\r\nDonec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.\r\n\r\nDonec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.\r\n\r\nDonec aliquet libero tellus, ut feugiat mi vehicula id. Aenean egestas, tortor quis eleifend dignissim, ipsum arcu venenatis magna, dapibus lobortis felis nunc a sem. Etiam lacus orci, fermentum fermentum augue at, mollis hendrerit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst. Semper consectetur ex. Etiam eget lectus feugiat, ultrices dui nec, varius mi. Quisque phaac diam sed laoreet. Praesent sit amet massa neque. Aliquam cursus posuere ligula, sed molestie erat porta quis. Proin mollis metus velit, interdum lorem egestas ut. Pellentesque sed nunc ultricies, euismod ante sit amet, iaculis erat. Donec porta ante sit amet massa scelerisque, pulvinar dolor pellentesque. Donec semper sapien non nisl consequat, ut cursus nunc vestibulum. Vivamus ut pharetra augue.', 'Duis in nulla a nisl gravida sodales a et ligula. Pellentesque dignissim, tortor sed facilisis porttitor, tellus tellus tempus ipsum, vitae molestie ante nisi sed.  Copy  Copy  Copy  Copy  Copy', '', 'inherit', 'closed', 'closed', '', '146-revision-v1', '', '', '2017-12-13 00:18:18', '2017-12-13 00:18:18', '', 146, 'http://henshaw-henry.com/146-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Henshaw & Henry, PC', '2017-12-01 23:53:41', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Henshaw & Henry, PC","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":4,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":5,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"select","id":6,"label":"Area of Practice","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"choices":[{"text":"First Choice","value":"First Choice","isSelected":false,"price":""},{"text":"Second Choice","value":"Second Choice","isSelected":false,"price":""},{"text":"Third Choice","value":"Third Choice","isSelected":false,"price":""}],"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Area of Practice","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","conditionalLogic":"","productField":"","enablePrice":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":7,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.2.5","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', '', '{"5a21eb8526bcb":{"id":"5a21eb8526bcb","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5a21eb8524abc":{"id":"5a21eb8524abc","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2017-12-02 00:00:41', '', 8),
(2, 1, '2017-12-03 18:28:16', '', 1),
(3, 1, '2017-12-04 20:58:25', '', 29),
(4, 1, '2017-12-05 21:03:07', '', 88),
(5, 1, '2017-12-06 21:19:02', '', 165),
(6, 1, '2017-12-07 21:22:23', '', 221),
(7, 1, '2017-12-07 21:22:23', '', 1),
(8, 1, '2017-12-08 21:33:09', '', 118),
(9, 1, '2017-12-11 17:06:38', '', 222),
(10, 1, '2017-12-12 18:45:53', '', 228) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(51, 2, 0),
(52, 2, 0),
(53, 2, 0),
(54, 2, 0),
(55, 2, 0),
(56, 2, 0),
(57, 2, 0),
(58, 2, 0),
(62, 2, 0),
(89, 2, 0),
(90, 2, 0),
(93, 2, 0),
(95, 2, 0),
(106, 4, 0),
(107, 4, 0),
(108, 4, 0),
(109, 4, 0),
(110, 4, 0),
(111, 4, 0),
(112, 4, 0),
(113, 4, 0),
(114, 4, 0),
(115, 4, 0),
(116, 4, 0),
(117, 5, 0),
(118, 5, 0),
(119, 5, 0),
(120, 5, 0),
(121, 5, 0),
(122, 5, 0),
(123, 5, 0),
(124, 5, 0),
(135, 2, 0),
(136, 2, 0),
(140, 1, 0),
(142, 1, 0),
(143, 1, 0),
(143, 8, 0),
(144, 1, 0),
(144, 6, 0),
(145, 1, 0),
(145, 7, 0),
(146, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 6),
(2, 2, 'nav_menu', '', 0, 15),
(4, 4, 'nav_menu', '', 0, 11),
(5, 5, 'nav_menu', '', 0, 8),
(6, 6, 'category', '', 0, 1),
(7, 7, 'category', '', 0, 1),
(8, 8, 'category', '', 0, 1),
(9, 9, 'category', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Pa Sidebar', 'pa-sidebar', 0),
(4, 'Pa Directory Menu Column One', 'pa-directory-menu-column-one', 0),
(5, 'Pa Directory Menu Column Two', 'pa-directory-menu-column-two', 0),
(6, 'Cat 1', 'cat-1', 0),
(7, 'Cat 2', 'cat-2', 0),
(8, 'Cat 3', 'cat-3', 0),
(9, 'Cat 4', 'cat-4', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', '1p21.admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '127'),
(17, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(18, 1, 'session_tokens', 'a:1:{s:64:"8e4316dcbc4ceadba5e80c68abd7b25c6acd529dbf3288093f2a40cbf09d4032";a:4:{s:10:"expiration";i:1513184852;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";s:5:"login";i:1513012052;}}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'edit_page_per_page', '200'),
(22, 1, 'nav_menu_recently_edited', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$Bn8Y5yPzFk36XUQ.teIPDX4SzWsfEp.', '1p21-admin', 'garrett@1point21interactive.com', '', '2017-11-14 18:39:52', '', 0, '1p21.admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

